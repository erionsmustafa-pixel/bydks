# BYD Kosova

Website for BYD electric cars in Kosovo: a key-style front page with three buttons (ATTO 3, ATTO 2, SEALION 7), a page for each model with a photo gallery, a business and fleet section, and a test-drive form. Available in Albanian (default), English and Serbian.

## Files
- `index.html`: the whole website (HTML, CSS and JavaScript)
- `img/`: the car photos (official BYD press photos; check with the importer that your use is allowed)

## Publish with GitHub Pages
1. Create a new repository on GitHub and upload `index.html`, `README.md` and the `img` folder.
2. Go to **Settings → Pages**.
3. Under **Branch**, choose `main` and `/ (root)`, then click **Save**.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Still to fill in
The showroom address, phone, email, opening hours and importer name are placeholders shown in yellow-brown brackets, e.g. `[+383 xx xxx xxx]`.
